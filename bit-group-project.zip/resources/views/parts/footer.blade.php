<footer class="footer">
    <div class="container-fluid">
        {{date("Y")}} © ProMES
    </div>
</footer>