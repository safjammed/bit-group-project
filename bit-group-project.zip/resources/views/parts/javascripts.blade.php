<!-- Vendor JS -->

<script type="text/javascript" src="/vendor/tether/js/tether.min.js"></script>
<script type="text/javascript" src="/vendor/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/vendor/detectmobilebrowser/detectmobilebrowser.js"></script>
<script type="text/javascript" src="/vendor/jscrollpane/jquery.mousewheel.js"></script>
<script type="text/javascript" src="/vendor/jscrollpane/mwheelIntent.js"></script>
<script type="text/javascript" src="/vendor/jscrollpane/jquery.jscrollpane.min.js"></script>
<script type="text/javascript" src="/vendor/waves/waves.min.js"></script>
<script type="text/javascript" src="/vendor/chartist/chartist.min.js"></script>
<script type="text/javascript" src="/vendor/switchery/dist/switchery.min.js"></script>
<script type="text/javascript" src="/vendor/flot/jquery.flot.min.js"></script>
<script type="text/javascript" src="/vendor/flot/jquery.flot.resize.min.js"></script>
<script type="text/javascript" src="/vendor/flot.tooltip/js/jquery.flot.tooltip.min.js"></script>
<script type="text/javascript" src="/vendor/CurvedLines/curvedLines.js"></script>
<script type="text/javascript" src="/vendor/TinyColor/tinycolor.js"></script>
<script type="text/javascript" src="/vendor/sparkline/jquery.sparkline.min.js"></script>
<script type="text/javascript" src="/vendor/raphael/raphael.min.js"></script>
<script type="text/javascript" src="/vendor/morris/morris.min.js"></script>
<script type="text/javascript" src="/vendor/jvectormap/jquery-jvectormap-2.0.3.min.js"></script>
<script type="text/javascript" src="/vendor/jvectormap/jquery-jvectormap-world-mill.js"></script>

<!-- Neptune JS -->
<script type="text/javascript" src="/js/app2.js"></script>
<script type="text/javascript" src="/js/demo.js"></script>



<!-- layouts for Notificaiton -->
@include ('_partial.message')

@yield('extra_js')


<script src="{{asset("js/custom.js")}}"></script>
<!-- APP SCRIPTS -->
{{--<script type="text/javascript" src="js//vendor/rickshaw/d3.v3.js"></script>--}}
{{--<script type="text/javascript" src="js//vendor/rickshaw/rickshaw.min.js"></script>--}}
{{--<script type="text/javascript" src="js/app2.js"></script>--}}
{{--<script type="text/javascript" src="js/app_plugins.js"></script>--}}
{{--<script type="text/javascript" src="js/app_demo.js"></script><!-- END APP SCRIPTS -->--}}
{{--<script type="text/javascript" src="js/app_demo_dashboard.js"></script>--}}