<?php if(Session::has('message')): ?>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/notification/overhang.min.css')); ?>" />
    <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/jquery-ui.min.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/notification/overhang.min.js')); ?>"></script>

    <script>
        // Some error notification

        $("body").overhang({
            type: "<?php echo e(Session::get('type')); ?>",
            message: "<?php echo e(Session::get('message')); ?>!",
            duration: 5,

            closeConfirm: true,
        });

    </script>

<?php endif; ?>