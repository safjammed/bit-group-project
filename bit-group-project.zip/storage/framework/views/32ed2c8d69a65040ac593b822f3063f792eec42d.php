<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-4 offset-md-4">
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger ">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <div class="input-group">
                        <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus placeholder="Email">

                        <?php if($errors->has('email')): ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                        <?php endif; ?>
                        <div class="input-group-addon"><i class="ti-email"></i></div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required placeholder="Password">

                        <?php if($errors->has('password')): ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                        <?php endif; ?>
                        <div class="input-group-addon"><i class="ti-key"></i></div>
                    </div>
                </div>
                <div class="form-group clearfix">
                    <div class="pull-xs-left">
                        <label class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                            <span class="custom-control-indicator"></span>
                            <span class="custom-control-description font-90">Remember me</span>
                        </label>
                    </div>
                    <?php if(Route::has('password.request')): ?>
                        <div class="pull-xs-right">
                            <a class="text-white font-90" href="<?php echo e(route('password.request')); ?>">Forgot password?</a>
                        </div>
                    <?php endif; ?>

                </div>
                <div class="row">
                    <div class="col-xs-6">
                        <button type="submit" class="btn btn-info btn-block label-left m-b-0-25">
                            <span class="btn-label"><i class="ti-face-smile"></i></span>
                            Sign In
                        </button>
                    </div>
                    <div class="col-xs-6">
                        <a href="<?php echo e(route('register')); ?>" class="btn btn-primary btn-block label-left m-b-0-25">
                            <span class="btn-label"><i class="ti-write"></i></span>
                            Register
                        </a>
                    </div>
                </div>

                
                    
                    
                
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>