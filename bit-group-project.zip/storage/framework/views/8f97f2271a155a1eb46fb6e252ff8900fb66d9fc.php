<!DOCTYPE html>
<html lang="en">
<head>

    <!-- Contain all css and header information -->
    <?php echo $__env->make('parts.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->yieldContent('extra_css'); ?>
</head>
<body class="auth-bg">

<div class="auth">
    <div class="auth-header">
        <h1>Neptune</h1>
        <h6>Welcome! Sign in to access the admin panel</h6>
    </div>
    <div class="container-fluid">
        <?php echo $__env->yieldContent('content'); ?>

    </div>
</div>
<?php echo $__env->make('parts.javascripts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>