<?php $__env->startSection('content'); ?>
    <div class="row">

        <div class="col-md-4 offset-md-4">
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger ">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('code')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <div class="input-group">
                        <input id="code" type="text" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="code" value="<?php echo e(old('code')); ?>" required autofocus placeholder="4 Digit Code">

                        <?php if($errors->has('code')): ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('code')); ?></strong>
                                    </span>
                        <?php endif; ?>
                        <div class="input-group-addon"><i class="ti-email"></i></div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-6">
                        <button type="submit" class="btn btn-info btn-block label-left m-b-0-25">
                            <span class="btn-label"><i class="ti-face-smile"></i></span>
                            Confirm Code
                        </button>
                    </div>
                    <div class="col-xs-6">
                        <a href="" class="btn btn-primary btn-block label-left m-b-0-25">
                            <span class="btn-label"><i class="ti-write"></i></span>
                            Resend Code
                        </a>
                    </div>
                </div>

                
                
                
                
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>