<!-- Header -->
<div class="site-header">
    <nav class="navbar navbar-light">
        <ul class="nav navbar-nav">
            <li class="nav-item m-r-1 hidden-lg-up">
                <a class="nav-link collapse-button" href="#">
                    <i class="ti-menu"></i>
                </a>
            </li>
        </ul>
        <ul class="nav navbar-nav pull-xs-right">
            <li class="nav-item dropdown">
                <a class="nav-link" onclick="event.preventDefault();document.getElementById('logout-form').submit();" aria-expanded="false">
                    <i class="ti-power-off px-3 py-3" style="border: 1px dashed #ccc;"></i>
                </a>
            </li>

            
                
                    
                
            
        </ul>
        <div class="navbar-toggleable-sm collapse" id="collapse-1">
            <ul class="nav navbar-nav">

                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" data-toggle="dropdown" aria-expanded="true">
                        <div class="avatar box-32">
                            <img src="/img/avatars/1.jpg" alt="">
                        </div>
                    </a>
                    <div class="dropdown-menu dropdown-menu-left animated flipInY">
                        
                            
                        
                        
                            
                        
                        
                            
                        
                        
                        

                        <a class="dropdown-item" href="<?php echo e(route("logout")); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();"><i class="ti-power-off m-r-0-5"></i> Sign out</a>
                        <form id="logout-form" action="<?php echo e(route("logout")); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
                <li class="dropdown-item-text">
                    <div class="pt-3 ml-5">
                    <h6 class="blue-text"><?php echo e(\Auth::user()->name); ?></h6>
                    <span class="grey-text"><?php echo e((\Auth::user()->getRoleNames())[0]); ?></span>
                    </div>
                </li>
            </ul>
        </div>
    </nav>
</div>