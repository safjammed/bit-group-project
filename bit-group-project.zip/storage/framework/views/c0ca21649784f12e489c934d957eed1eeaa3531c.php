<footer class="footer">
    <div class="container-fluid">
        <?php echo e(date("Y")); ?> © ProMES
    </div>
</footer>